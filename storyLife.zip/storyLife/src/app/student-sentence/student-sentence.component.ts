import { Component, OnInit } from '@angular/core';
import { RouterLink, Router } from '@angular/router';
import { database } from 'firebase';
import { DatabaseService } from '../services/database.service';
import { CookieService } from 'angular2-cookie/services/cookies.service';
import { User } from '../users/user';

@Component({
  selector: 'app-student-sentence',
  templateUrl: './student-sentence.component.html',
  styleUrls: ['./student-sentence.component.css']
})
export class StudentSentenceComponent implements OnInit {
  sentence:string="";
  constructor(public router: Router,public db: DatabaseService,private cookieService: CookieService) { }

  ngOnInit() {
    if(<User>this.cookieService.getObject('user')!=undefined)
    this.db.loggedInUser = <User>this.cookieService.getObject('user');
   else
    this.router.navigate(['/'])

  }
  GoToQuestionnaire()
  {
    if(this.sentence=="")
      alert("לא נבחר מקצוע");
    else
    {

    this.db.loggedInUser.studSentence=this.sentence;
    

    this.db.updateListing(this.db.loggedInUser.uid);
    this.router.navigate(['studen-Questionnaire']);
    }

  }
  selectSentence(event:any)
  {
    this.sentence=event.target.value;
  }
}


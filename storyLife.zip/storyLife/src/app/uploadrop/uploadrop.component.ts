import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uploadrop',
  templateUrl: './uploadrop.component.html',
  styleUrls: ['./uploadrop.component.css']
})
export class UploadropComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

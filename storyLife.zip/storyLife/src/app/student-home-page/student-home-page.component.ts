import { Component, OnInit } from '@angular/core';
import { RouterLink, Router } from '@angular/router';
import { DatabaseService } from '../services/database.service';
import { CookieService } from 'angular2-cookie/services/cookies.service';
import { User } from '../users/user';

@Component({
  selector: 'app-student-home-page',
  templateUrl: './student-home-page.component.html',
  styleUrls: ['./student-home-page.component.css']
})
export class StudentHomePageComponent implements OnInit {

  constructor(public router: Router,public db: DatabaseService,
    private cookieService: CookieService) { }

  ngOnInit() {
    if(<User>this.cookieService.getObject('user')!=undefined)
    this.db.loggedInUser = <User>this.cookieService.getObject('user');
   else
    this.router.navigate(['/'])

  }
  GoToAmI()
  {
      this.router.navigate(['am-i']);
    
    
  }
  GoToSchedule()
  {
    this.router.navigate(['Schedule']);

  }
}

import { Component, OnInit } from '@angular/core';
import { DatabaseService } from '../services/database.service';
import { User } from '../users/user';
import { Router } from '@angular/router';
import { CookieService } from 'angular2-cookie/services/cookies.service';

@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.css']
})
export class AdminHomeComponent implements OnInit {

  constructor(public cookieService: CookieService,public db:DatabaseService, private router:Router) { }

  ngOnInit() {
    if(<User>this.cookieService.getObject('user')!=undefined)
    this.db.loggedInUser = <User>this.cookieService.getObject('user');
   else
    this.router.navigate(['/'])
  }

}

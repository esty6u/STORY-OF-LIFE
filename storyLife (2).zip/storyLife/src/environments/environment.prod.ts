export const environment = {
  production: true,
  firebase:
  {
    apiKey: "AIzaSyDboHEtLNJok03LRO3MgSA5SLyXSX_jLN8",
    authDomain: "storylife-8cffc.firebaseapp.com",
    databaseURL: "https://storylife-8cffc.firebaseio.com",
    projectId: "storylife-8cffc",
    storageBucket: "storylife-8cffc.appspot.com",
    messagingSenderId: "940429693009"
  }
  
};

(function(window, undefined) {
  var dictionary = {
    "0fa9ccd4-3817-48f4-a4d6-7d056d693ca0": "admin login",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Screen 1",
    "4ea71d4e-d735-486e-a568-071e8e829402": "studentLogin",
    "089a8c7b-83b0-4422-9eee-b431e6e5949d": "teacherLogin",
    "81632898-de54-49ab-aeed-f0eb4f992559": "study",
    "6f4d79ff-4a57-442f-9162-997e0d420699": "parentLogin",
    "4250fa56-1904-481e-9b06-887344d9d5ef": "homeStud",
    "234eebd4-d650-4428-b911-e7e1acd39e6f": "miAni",
    "e73b655d-d3ec-4dcc-a55c-6e0293422bde": "960 grid - 16 columns",
    "ef07b413-721c-418e-81b1-33a7ed533245": "960 grid - 12 columns",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);
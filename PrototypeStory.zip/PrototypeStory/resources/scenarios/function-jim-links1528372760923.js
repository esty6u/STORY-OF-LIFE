(function(window, undefined) {

  var jimLinks = {
    "0fa9ccd4-3817-48f4-a4d6-7d056d693ca0" : {
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_12" : [
        "4ea71d4e-d735-486e-a568-071e8e829402"
      ],
      "Button_14" : [
        "089a8c7b-83b0-4422-9eee-b431e6e5949d"
      ],
      "Button_15" : [
        "6f4d79ff-4a57-442f-9162-997e0d420699"
      ],
      "Button_16" : [
        "0fa9ccd4-3817-48f4-a4d6-7d056d693ca0"
      ]
    },
    "4ea71d4e-d735-486e-a568-071e8e829402" : {
      "Button_7" : [
        "4250fa56-1904-481e-9b06-887344d9d5ef"
      ],
      "Button_8" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "089a8c7b-83b0-4422-9eee-b431e6e5949d" : {
    },
    "6f4d79ff-4a57-442f-9162-997e0d420699" : {
    },
    "4250fa56-1904-481e-9b06-887344d9d5ef" : {
      "Label_59" : [
        "234eebd4-d650-4428-b911-e7e1acd39e6f"
      ]
    },
    "234eebd4-d650-4428-b911-e7e1acd39e6f" : {
      "Ellipse_1" : [
        "81632898-de54-49ab-aeed-f0eb4f992559"
      ],
      "Ellipse_2" : [
        "81632898-de54-49ab-aeed-f0eb4f992559"
      ],
      "Ellipse_3" : [
        "81632898-de54-49ab-aeed-f0eb4f992559"
      ],
      "Ellipse_4" : [
        "81632898-de54-49ab-aeed-f0eb4f992559"
      ],
      "Ellipse_5" : [
        "81632898-de54-49ab-aeed-f0eb4f992559"
      ],
      "Ellipse_6" : [
        "81632898-de54-49ab-aeed-f0eb4f992559"
      ],
      "Ellipse_7" : [
        "81632898-de54-49ab-aeed-f0eb4f992559"
      ],
      "Ellipse_8" : [
        "81632898-de54-49ab-aeed-f0eb4f992559"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);